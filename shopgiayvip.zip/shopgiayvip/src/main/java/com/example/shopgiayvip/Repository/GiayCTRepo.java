package com.example.shopgiayvip.Repository;

import com.example.shopgiayvip.Entity.GiayChiTiet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GiayCTRepo extends JpaRepository<GiayChiTiet,Integer> {
}
