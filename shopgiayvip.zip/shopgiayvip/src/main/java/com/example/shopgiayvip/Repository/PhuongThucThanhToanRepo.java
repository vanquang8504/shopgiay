package com.example.shopgiayvip.Repository;

import com.example.shopgiayvip.Entity.PhuongThucThanhToan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PhuongThucThanhToanRepo extends JpaRepository<PhuongThucThanhToan, Integer> {
}
